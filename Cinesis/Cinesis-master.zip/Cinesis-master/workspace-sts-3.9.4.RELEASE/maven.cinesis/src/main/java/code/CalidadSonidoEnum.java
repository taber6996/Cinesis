package code;

public enum CalidadSonidoEnum {
	ESTEREO,DOLBY,CINCOPUNTOUNO
}