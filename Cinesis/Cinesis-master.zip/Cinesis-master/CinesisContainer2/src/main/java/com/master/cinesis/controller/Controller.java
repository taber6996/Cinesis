package com.master.cinesis.controller;

public class Controller {
	
	private ControllerInter controlador;
	
	private ControllerParser controladorParser;

}
