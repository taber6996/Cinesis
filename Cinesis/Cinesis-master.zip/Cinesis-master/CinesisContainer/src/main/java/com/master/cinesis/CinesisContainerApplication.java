package com.master.cinesis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinesisContainerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinesisContainerApplication.class, args);
	}
}
