package com.master.cinesis.model;

public enum CalidadSonidoEnum {
	ESTEREO,DOLBY,CINCOPUNTOUNO
}
