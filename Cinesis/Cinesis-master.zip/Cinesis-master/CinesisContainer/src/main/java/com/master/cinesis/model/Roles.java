package com.master.cinesis.model;

public enum Roles {

}
